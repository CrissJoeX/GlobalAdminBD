CREATE DATABASE IF NOT EXISTS veterinaria;

USE `veterinaria`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `agendaconsultas`;

CREATE TABLE `agendaconsultas` (
  `idAgendaConsultas` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(600) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `idMascota` int NOT NULL,
  `idVeterinario` int NOT NULL,
  `estatus` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idAgendaConsultas`),
  KEY `fk_AgendaConsultas_Mascota1_idx` (`idMascota`),
  KEY `fk_AgendaConsultas_Veterinario1_idx` (`idVeterinario`),
  CONSTRAINT `fk_AgendaConsultas_Mascota1` FOREIGN KEY (`idMascota`) REFERENCES `mascota` (`idMascota`),
  CONSTRAINT `fk_AgendaConsultas_Veterinario1` FOREIGN KEY (`idVeterinario`) REFERENCES `veterinario` (`idVeterinario`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `agendaconsultas` VALUES (1,"\tConsulta de rutina \t","2023-08-10",31,7,1),
(2,"\tVacunación anual \t","2023-08-11",3,9,1),
(3,"\tChequeo general\t","2023-08-12",25,3,1),
(4,"\tSeguimiento de tratamiento\t","2023-08-13",16,10,1),
(5,"\tExamen de salud \t","2023-08-14",12,1,1),
(6,"\tConsulta de emergencia \t","2023-08-15",35,7,1),
(7,"\tEvaluación post-operatoria \t","2023-08-16",16,3,1),
(8,"\tChequeo general  \t","2023-08-17",26,4,1),
(9,"\tControl de diabetes\t","2023-08-18",16,8,1),
(10,"\tEvaluación de artritis \t","2023-08-19",18,4,1),
(11,"\tChequeo general \t","2023-08-20",20,6,1),
(12,"\tConsulta de rutina\t","2023-08-21",9,5,1),
(13,"\tVacunación anual \t","2023-08-22",5,2,1),
(14,"\tSeguimiento de tratamiento \t","2023-08-23",9,9,1),
(15,"\tExamen de salud \t","2023-08-24",29,3,1),
(16,"\t Consulta de emergencia \t","2023-08-25",37,4,1),
(17,"\tEvaluación post-operatoria \t","2023-08-26",42,7,1),
(18,"\tChequeo general  \t","2023-08-27",17,9,1),
(19,"\tControl de diabetes \t","2023-08-28",42,3,1),
(20,"\tEvaluación de artritis\t","2023-08-29",60,1,1),
(21,"\tChequeo general \t","2023-08-30",25,1,1),
(22,"\tConsulta de rutina \t","2023-08-31",22,7,1),
(23,"\tVacunación anual \t","2023-09-01",12,3,1),
(24,"\tSeguimiento de tratamiento \t","2023-09-02",35,4,1),
(25,"\tExamen de salud \t","2023-09-03",48,7,1),
(26,"\tConsulta de emergencia  \t","2023-09-04",16,9,1),
(27,"\tEvaluación post-operatoria \t","2023-09-05",19,1,1),
(28,"\tRevisión de herida quirúrgica \t","2023-09-06",18,4,1),
(29,"\tControl de diabetes \t","2023-09-07",20,2,1),
(30,"\tEvaluación de artritis \t","2023-09-08",23,9,1),
(31,"\tChequeo general \t","2023-09-09",5,5,1),
(32,"\tConsulta de rutina \t","2023-09-10",28,6,1),
(33,"\tVacunación anual \t","2023-09-11",8,7,1),
(34,"\tSeguimiento de tratamiento\t","2023-09-12",37,9,1),
(35,"\t Examen de salud\t","2023-09-13",16,2,1),
(36,"\t Consulta de emergencia \t","2023-09-14",6,5,1),
(37,"\tChequeo general  \t","2023-09-15",42,1,1),
(38,"\tChequeo general  \t","2023-09-16",3,7,1),
(39,"\t Control de diabetes \t","2023-09-17",5,3,1),
(40,"\tEvaluación de artritis \t","2023-09-18",16,4,1),
(41,"\tChequeo general\t","2023-09-19",12,8,1),
(42,"\t Consulta de rutina \t","2023-09-20",35,4,1),
(43,"\tVacunación anual \t","2023-09-21",8,6,1),
(44,"\tSeguimiento de tratamiento \t","2023-09-22",26,5,1),
(45,"\tExamen de salud  \t","2023-09-23",32,2,1),
(46,"\tConsulta de emergencia \t","2023-09-24",18,9,1),
(47,"\tEvaluación post-operatoria \t","2023-09-25",20,8,1),
(48,"\tChequeo general  \t","2023-09-26",9,3,1),
(49,"\tControl de diabetes \t","2023-09-27",8,7,1),
(50,"\tEvaluación de artritis \t","2023-09-28",28,9,1),
(51,"\tChequeo general  \t","2023-09-29",2,3,1),
(52,"\tConsulta de rutina \t","2023-09-30",37,10,1),
(53,"\t Vacunación anual  \t","2023-10-01",1,1,1),
(54,"\tSeguimiento de tratamiento\t","2023-10-02",17,7,1),
(55,"\tExamen de salud\t","2023-10-03",5,4,1),
(56,"\tConsulta de emergencia \t","2023-10-04",51,8,1),
(57,"\tEvaluación post-operatoria \t","2023-10-05",44,8,1),
(58,"\tRevisión de herida quirúrgica \t","2023-10-06",37,4,1),
(59,"\t Control de diabetes \t","2023-10-07",31,6,1),
(60,"\tEvaluación de artritis\t","2023-10-08",17,5,1);


DROP TABLE IF EXISTS `calle`;

CREATE TABLE `calle` (
  `idCalle` int NOT NULL AUTO_INCREMENT,
  `calle` varchar(60) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idCalle`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `calle` VALUES (1,"\t Avenida Principal\t"),
(2,"\t Calle del Sol\t"),
(3,"\tCallejón de Flores\t"),
(4,"\t Paseo de la Luna\t"),
(5,"\tCalle Real\t"),
(6,"\tBoulevard del Río\t"),
(7,"\tCamino del Bosque\t"),
(8,"\tPaseo de la Montaña\t"),
(9,"\tAvenida de los Pájaros\t"),
(10,"\tCallejón del Arte\t"),
(11,"\tCallejón de la Historia\t"),
(12,"\tPaseo de los Jardines\t"),
(13,"\tCallejón de los Sabores\t"),
(14,"\tAvenida de la Paz\t"),
(15,"\tBoulevard de las Estrellas\t"),
(16,"\tCalle del Bosque\t"),
(17,"\tAvenida de los Pinos\t"),
(18,"\tCalle Juárez\t"),
(19,"\tCalle Primavera\t"),
(20,"\tAvenida Revolución\t"),
(21,"\tCalle de la Luna\t"),
(22,"\tPaseo de la Montaña\t"),
(23,"\tAvenida del Río\t"),
(24,"\tCalle de la Rosa\t"),
(25,"\tProlongación Reforma\t"),
(26,"\tCalle de las Flores\t"),
(27,"\tAvenida Hidalgo\t"),
(28,"\tCalle del Carmen\t"),
(29,"\tBoulevard Independencia\t"),
(30,"\tCalle Victoria\t"),
(31,"\tRevolucion\t");


DROP TABLE IF EXISTS `ciudad`;

CREATE TABLE `ciudad` (
  `idCiudad` int NOT NULL AUTO_INCREMENT,
  `ciudad` varchar(60) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idCiudad`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `ciudad` VALUES (1,"\tAguascalientes\t"),
(2,"\tMexicali\t"),
(3,"\tLa Paz\t"),
(4,"\tSan Francisco de Campeche\t"),
(5,"\tTuxtla Gutiérrez\t"),
(6,"\tChihuahua\t"),
(7,"\tCiudad de México\t"),
(8,"\tSaltillo\t"),
(9,"\tColima\t"),
(10,"\tDurango\t"),
(11,"\tToluca\t"),
(12,"\tGuanajuato\t"),
(13,"\tChilpancingo\t"),
(14,"\tPachuca\t"),
(15,"\tGuadalajara\t"),
(16,"\tMorelia\t"),
(17,"\tCuernavaca\t"),
(18,"\tTepic\t"),
(19,"\tMonterrey\t"),
(20,"\tOaxaca de Juárez\t"),
(21,"\tPuebla de Zaragoza\t"),
(22,"\tSantiago de Querétaro\t"),
(23,"\tChetumal\t"),
(24,"\tSan Luis Potosí\t"),
(25,"\tCuliacán\t"),
(26,"\tHermosillo\t"),
(27,"\tVillahermosa\t"),
(28,"\tCiudad Victoria\t"),
(29,"\tTlaxcala\t"),
(30,"\tXalapa\t"),
(31,"\tMérida\t");


DROP TABLE IF EXISTS `cliente`;

CREATE TABLE `cliente` (
  `idCliente` int NOT NULL AUTO_INCREMENT,
  `RFC` varchar(13) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `nombre` varchar(45) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `apaterno` varchar(45) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `amaterno` varchar(45) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `telefono` varchar(14) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `idCalle` int NOT NULL,
  `idColonia` int NOT NULL,
  `idCiudad` int NOT NULL,
  `idEstado` int NOT NULL,
  `idPais` int NOT NULL,
  `estatus` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idCliente`),
  KEY `fk_Cliente_Calle1_idx` (`idCalle`),
  KEY `fk_Cliente_Ciudad1_idx` (`idCiudad`),
  KEY `fk_Cliente_Estado1_idx` (`idEstado`),
  KEY `fk_Cliente_Pais1_idx` (`idPais`),
  KEY `fk_Cliente_Colonia_idx` (`idColonia`) USING BTREE,
  CONSTRAINT `fk_Cliente_Calle1` FOREIGN KEY (`idCalle`) REFERENCES `calle` (`idCalle`),
  CONSTRAINT `fk_Cliente_Ciudad1` FOREIGN KEY (`idCiudad`) REFERENCES `ciudad` (`idCiudad`),
  CONSTRAINT `fk_Cliente_Colonia1` FOREIGN KEY (`idColonia`) REFERENCES `colonia` (`idColonia`),
  CONSTRAINT `fk_Cliente_Estado1` FOREIGN KEY (`idEstado`) REFERENCES `estado` (`idEstado`),
  CONSTRAINT `fk_Cliente_Pais1` FOREIGN KEY (`idPais`) REFERENCES `pais` (`idPais`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `cliente` VALUES (1,"\tABCD123456  ","\tJuan        \t","\tPérez       \t","\tGarcía     \t","\t555-123-4567 ",1,3,4,2,1,1),
(2,"\tEFGH987654  ","\tMaría       \t","\tRodríguez   \t","\tLópez      \t","\t 555-234-5678",2,27,1,7,1,1),
(3,"\tIJKL456789  ","\tSantiago    \t","\tMartínez    \t","\tGarcía     \t","\t555-345-6789\t",6,28,2,4,1,1),
(4,"\tMNOP890123  ","\tValeria     \t","\tLópez       \t","\tSolis\t","\t555-456-7890\t",8,26,8,3,1,1),
(5,"\tQRST234567  ","\tEmiliano    \t","\tJuarez\t","\tMartínez   \t","\t555-567-8901\t",2,30,2,1,1,1),
(6,"\tUVWX345678  ","\tRegina      \t","\tGarcía      \t","\tLópez      \t","\t555-678-9012\t",23,9,16,29,1,1),
(7,"\tYZAB456789  ","\tMatías      \t","\tGutierrez\t","\tRodríguez  \t","\t555-789-0123\t",9,8,25,13,1,1),
(8,"\tCDEF567890  ","\tFernanda    \t","\tSanchez\t","\tMarquez\t","\t555-890-1234\t",3,3,3,3,1,1),
(9,"\tGHIJ678901  ","\tSebastián   \t","\tGarcía      \t","\tLópez      \t","\t555-901-2345\t",4,2,1,4,1,1),
(10,"\tKLMN789012  ","\tXimena      \t","\tLópez       \t","\tPerez\t","\t555-012-3456\t",5,5,5,5,1,1),
(11,"\tOPQR890123  ","\tSantiago    \t","\tRodríguez   \t","\tGarcía     \t","\t555-123-4567\t",4,12,11,26,1,1),
(12,"\tSTUV901234  ","\tMaría       \t","\tGarcía      \t","\tLópez      \t","\t555-234-5678\t",5,5,5,5,1,1),
(13,"\tWXYZ012345  ","\tValeria     \t","\tMartínez    \t","\tRodríguez  \t","\t555-345-6789\t",13,12,6,29,1,1),
(14,"\tABCD123456  ","\tEmiliano    \t","\tRodríguez   \t","\tGarcía     \t","\t555-456-7890\t",1,1,1,1,1,1),
(15,"\tEFGH987654  ","\tRegina      \t","\tGarcía      \t","\tLópez      \t","\t555-567-8901\t",16,15,4,9,1,1),
(16,"\tIJKL456789  ","\tMatías      \t","\tMartínez    \t","\tRodríguez  \t","\t555-678-9012\t",2,2,21,2,1,1),
(17,"\tMNOP890123  ","\tFernanda    \t","\tHernandez\t","\tMartínez   \t","\t555-789-0123\t",17,17,3,17,1,1),
(18,"\tQRST234567  ","\tSantiago    \t","\tGarcía      \t","\tLópez      \t","\t555-890-1234\t",3,3,8,3,1,1),
(19,"\tUVWX345678  ","\tValentina   \t","\tLópez       \t","\tRodríguez  \t","\t555-901-2345\t",19,19,9,19,1,1),
(20,"\tYZAB456789  ","\tEmiliano    \t","\tMartínez    \t","\tGarcía     \t","\t555-012-3456\t",20,2,5,1,1,1),
(21,"\tCDEF567890  ","\tXimena      \t","\tGarcía      \t","\tLópez      \t","\t555-123-4567\t",21,21,2,21,1,1),
(22,"\tGHIJ678901  ","\tMaría       \t","\tRodríguez   \t","\tMartínez   \t","\t555-234-5678\t",3,3,3,3,1,1),
(23,"\tKLMN789012  ","\tValeria     \t","\tLópez       \t","\tGarcía     \t","\t555-345-6789 ",5,8,6,1,1,1),
(24,"\tOPQR890123  ","\tJuan        \t","\tGarcía      \t","\tRodríguez  \t","\t555-456-7890\t",21,9,9,9,1,1),
(25,"\tSTUV901234  ","\tSantiago    \t","\tRodríguez   \t","\tMartínez   \t","\t555-567-8901\t",3,31,19,11,1,1),
(26,"\tWXYZ012345  ","\tRegina      \t","\tLópez       \t","\tGarcía     \t","\t555-678-9012\t",8,3,3,3,1,1),
(27,"\tABCD123456  ","\tMatías      \t","\tGarcía      \t","\tRodríguez  \t","\t555-789-0123\t",9,27,6,9,1,1),
(28,"\tEFGH987654  ","\tXimena      \t","\tMartínez    \t","\tLópez      \t","\t555-890-1234\t",9,28,24,21,1,1),
(29,"\tIJKL456789  ","\tJuan        \t","\tRodríguez   \t","\tGarcía     \t","\t555-901-2345\t",3,26,26,26,1,1),
(30,"\tMNOP890123  ","\tValentina   \t","\tLópez       \t","\tMartínez   \t","\t555-012-3456\t",28,30,16,8,1,1),
(31,"\tQRST234567  ","\tEmiliano    \t","\tGarcía      \t","\tRod\t","\t555-123-4567\t",6,3,1,31,1,1),
(32,"\tUVWX345678  ","\tSantiago    \t","\tRodríguez   \t","\tríguez  \t","\t555-234-5678\t",14,31,9,3,1,1),
(33,"\tYZAB456789  ","\tValeria     \t","\tMartínez    \t","\tMartínez   \t","\t555-345-6789\t",29,30,20,13,1,1),
(34,"\tCDEF567890  ","\tJuan        \t","\tGarcía      \t","\tLópez      \t","\t555-456-7890\t",11,25,10,22,1,1),
(35,"\tGHIJ678901  ","\tMaría       \t","\tRodríguez   \t","\tRodríguez  \t","\t555-567-8901\t",22,2,19,1,1,1),
(36,"\tKLMN789012  ","\tSantiago    \t","\tLópez       \t","\tMartínez   \t","\t 555-678-9012",16,4,5,31,1,1),
(37,"\tOPQR890123  ","\tRegina      \t","\tGarcía      \t","\tGarcía     \t","\t555-789-0123\t",8,31,3,1,1,1),
(38,"\tSTUV901234  ","\tMatías      \t","\tMartínez    \t","\tRodríguez  \t","\t555-890-1234\t",23,1,2,3,1,1),
(39,"\tWXYZ012345  ","\tXimena      \t","\tRodríguez   \t","\tLópez      \t","\t555-901-2345 ",8,8,8,8,1,1),
(40,"\tABCD123456  ","\tValentina   \t","\tLópez       \t","\tGarcía     \t","\t555-012-3456\t",20,11,24,25,1,1),
(41,"\tEFGH987654  ","\tSantiago    \t","\tGarcía      \t","\tMartínez   \t","\t555-123-4567\t",5,5,5,5,1,1),
(42,"\tIJKL456789  ","\tMaría       \t","\tRodríguez   \t","\tRodríguez  \t","\t555-234-5678\t",22,13,30,4,1,1),
(43,"\tMNOP890123  ","\tJuan        \t","\tMartínez    \t","\tMartínez   \t","\t555-345-6789\t",1,21,2,16,1,1),
(44,"\tQRST234567  ","\tValeria     \t","\tGarcía      \t","\tLópez      \t","\t555-456-7890\t",15,3,5,15,1,1),
(45,"\tUVWX345678  ","\tSantiago    \t","\tRodríguez   \t","\tRodríguez  \t","\t555-567-8901\t",2,8,2,14,1,1),
(46,"\tYZAB456789  ","\tMaría       \t","\tGarcía      \t","\tMartínez   \t","\t555-678-9012\t",17,5,17,6,1,1),
(47,"\tCDEF567890  ","\tMatías      \t","\tMartínez    \t","\tLópez      \t","\t555-789-0123\t",3,9,7,5,1,1),
(48,"\tGHIJ678901  ","\tValentina   \t","\tRodríguez   \t","\tRodríguez  \t","\t555-890-1234\t",19,3,19,19,1,1),
(49,"\tKLMN789012  ","\tSantiago    \t","\tGarcía      \t","\tLópez      \t","\t555-901-2345\t",20,12,31,7,1,1),
(50,"\tOPQR890123  ","\tMaría       \t","\tRodríguez   \t","\tMartínez   \t","\t555-012-3456\t",29,31,15,27,1,1),
(51,"\tSTUV901234  ","\tJuan        \t","\tMartínez    \t","\tLópez      \t","\t 555-123-4567",3,3,2,3,1,1),
(52,"\tWXYZ012345  ","\tValeria     \t","\tGarcía      \t","\tRodríguez  \t","\t555-234-5678 ",8,6,17,1,1,1),
(53,"\tABCD123456  ","\tSantiago    \t","\tRodríguez   \t","\tMartínez   \t","\t555-345-6789\t",9,5,3,9,1,1),
(54,"\tEFGH987654  ","\tMaría       \t","\tGarcía      \t","\tLópez      \t","\t555-456-7890 ",9,9,19,31,1,1),
(55,"\tIJKL456789  ","\tJuan        \t","\tRodríguez   \t","\tRodríguez  \t","\t555-567-8901\t",3,1,20,3,1,1),
(56,"\tMNOP890123  ","\tValentina   \t","\tGarcía      \t","\tMartínez   \t","\t555-678-9012\t",31,19,21,27,1,1),
(57,"\tQRST234567  ","\tMatías      \t","\tMartínez    \t","\tLópez      \t","\t555-789-0123 ",1,4,2,28,1,1),
(58,"\tUVWX345678  ","\tJuan        \t","\tGarcía      \t","\tRodríguez  \t","\t555-890-1234\t",26,26,26,26,1,1),
(59,"\tYZAB456789  ","\tSantiago    \t","\tRodríguez   \t","\tMartínez   \t","\t555-901-2345\t",30,30,30,30,1,1),
(60,"\tCDEF567890  ","\tValeria     \t","\tLópez       \t","\tLópez      \t","\t555-012-3456\t",5,7,4,9,1,1);


DROP TABLE IF EXISTS `colonia`;

CREATE TABLE `colonia` (
  `idColonia` int NOT NULL AUTO_INCREMENT,
  `colonia` varchar(60) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`idColonia`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `colonia` VALUES (1,"\tResidencial Norte\t"),
(2,"\tCentro Hist"),
(3,"\t Villa de los Pinos\t"),
(4,"\tLos Alamos\t"),
(5,"\tSan Juan \t"),
(6,"\t Los Cerezos\t"),
(7,"\tLa Esperanza\t"),
(8,"\tLos Laureles\t"),
(9,"\tLa Floresta\t"),
(10,"\tEl Rosario\t"),
(11,"\t El Vergel\t"),
(12,"\tLos P"),
(13,"\tLas Acacias \t"),
(14,"\tLa Colina \t"),
(15,"\tSan Pedro \t"),
(16,"\tColonia del Sol\t"),
(17,"\tColonia San Juan\t"),
(18,"\tColonia Centro\t"),
(19,"\tColonia Los Alamos\t"),
(20,"\tColonia La Paz\t"),
(21,"\tColonia Santa Mar"),
(22,"\tColonia El Mirador\t"),
(23,"\tColonia La Fuente\t"),
(24,"\tColonia Los Pinos\t"),
(25,"\tColonia Benito Ju"),
(26,"\tColonia San Miguel\t"),
(27,"\tColonia San Pedro\t"),
(28,"\tColonia San Rafael\t"),
(29,"\tNueva Esperanza\t"),
(30,"\tSanta Cecilia\t"),
(31,"\tPirules\t");


DROP TABLE IF EXISTS `concepto`;

CREATE TABLE `concepto` (
  `idConcepto` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(500) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idConcepto`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `concepto` VALUES (1,"\tConsulta general \t"),
(2,"\tVacunación\t"),
(3,"\tTratamiento médico\t"),
(4,"\tCirugía \t"),
(5,"\tAnálisis de laboratorio \t"),
(6,"\tRadiografía \t"),
(7,"\tDesparasitación \t"),
(8,"\t Estudios diagnósticos avanzados \t"),
(9,"\tHospitalización\t"),
(10,"\t Limpieza dental \t"),
(11,"\tMedicamentos \t"),
(12,"\tServicio de urgencias\t"),
(13,"\tMicrochip \t"),
(14,"\tEsterilización quirúrgica \t"),
(15,"\tServicio de peluquería y aseo \t");


DROP TABLE IF EXISTS `consultorio`;

CREATE TABLE `consultorio` (
  `idConsultorio` int NOT NULL AUTO_INCREMENT,
  `telefono` varchar(12) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `horario` varchar(15) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `idDireccionConsultorio` int NOT NULL,
  `estatus` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idConsultorio`),
  KEY `fk_Consultorio_DireccionConsultorio1_idx` (`idDireccionConsultorio`),
  CONSTRAINT `fk_Consultorio_DireccionConsultorio1` FOREIGN KEY (`idDireccionConsultorio`) REFERENCES `direccionconsultorio` (`idDireccionConsultorio`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `consultorio` VALUES (1,"\t55-1234-567","\t09:00-18:00\t",9,1),
(2,"\t55-9876-543","\t08:00-17:00\t",2,1),
(3,"\t55-5555-555","\t10:00-19:00\t",6,1),
(4,"\t55-8888-888","\t09:30-18:30\t",2,1),
(5,"\t 55-4444-44","\t08:30-17:30\t",4,1),
(6,"\t 55-7777-77","\t09:00-18:00\t",6,1),
(7,"\t55-6666-666","\t10:00-19:00\t",10,1),
(8,"\t55-2222-222","\t08:00-17:00\t",8,1),
(9,"\t55-9999-999","\t09:30-18:3\t",9,1),
(10,"\t55-3333-333","\t08:30-17:30\t",1,1);


DROP TABLE IF EXISTS `direccionconsultorio`;

CREATE TABLE `direccionconsultorio` (
  `idDireccionConsultorio` int NOT NULL AUTO_INCREMENT,
  `calle` varchar(45) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `numero` varchar(4) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `colonia` varchar(45) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `idCiudad` int NOT NULL,
  PRIMARY KEY (`idDireccionConsultorio`),
  KEY `fk_DireccionConsultorio_Ciudad1_idx` (`idCiudad`),
  CONSTRAINT `fk_DireccionConsultorio_Ciudad1` FOREIGN KEY (`idCiudad`) REFERENCES `ciudad` (`idCiudad`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `direccionconsultorio` VALUES (1,"\tCalle 5 de Mayo\t",10,"\tCentro\t",7),
(2,"\tCalle Insurgentes Sur\t",100,"\tDel Valle\t",7),
(3,"\tCalle Reforma \t",500,"\tJuarez\t",7),
(4,"\tCalle Tlalpan\t",300,"\tPortales\t",7),
(5,"\tCalle Álvaro Obregón\t",200,"\tRoma\t",7),
(6,"\tCalle Patriotismo\t",408,"\tlos Pinos \t",7),
(7,"\tCalle Paseo de la Reforma\t",222,"\tCuauhtémoc \t",7),
(8,"\tCalle Miguel Ángel de Quevedo\t",112,"\tCoyoacán \t",7),
(9,"\tAvenida Universidad\t",1200,"\tColonia Xoco \t",7),
(10,"\tInsurgentes Norte\t",800,"\tLindavista \t",7);


DROP TABLE IF EXISTS `estado`;

CREATE TABLE `estado` (
  `idEstado` int NOT NULL AUTO_INCREMENT,
  `estado` varchar(45) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idEstado`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `estado` VALUES (1,"\tAguascalientes\t"),
(2,"\tBaja California\t"),
(3,"\tBaja California Sur\t"),
(4,"\tCampeche\t"),
(5,"\tChiapas\t"),
(6,"\tChihuahua\t"),
(7,"\tCiudad de México\t"),
(8,"\tCoahuila\t"),
(9,"\tColima\t"),
(10,"\tDurango\t"),
(11,"\tEstado de México\t"),
(12,"\tGuanajuato\t"),
(13,"\tGuerrero\t"),
(14,"\tHidalgo\t"),
(15,"\tJalisco\t"),
(16,"\tMichoacán\t"),
(17,"\tMorelos\t"),
(18,"\tNayarit\t"),
(19,"\tNuevo León\t"),
(20,"\tOaxaca\t"),
(21,"\tPuebla\t"),
(22,"\tQuerétaro\t"),
(23,"\tQuintana Roo\t"),
(24,"\tSan Luis Potosí\t"),
(25,"\tSinaloa\t"),
(26,"\tSonora\t"),
(27,"\tTabasco\t"),
(28,"\tTamaulipas\t"),
(29,"\tTlaxcala\t"),
(30,"\tVeracruz\t"),
(31,"\tYucatán\t");


DROP TABLE IF EXISTS `expediente`;

CREATE TABLE `expediente` (
  `idExpediente` int NOT NULL AUTO_INCREMENT,
  `idMascota` int DEFAULT NULL,
  `idVacuna` int DEFAULT NULL,
  `estatus` tinyint(1) DEFAULT NULL,
  `diagnostico` varchar(100) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idExpediente`),
  KEY `idMascota_idx` (`idMascota`),
  KEY `idVacuna_idx` (`idVacuna`),
  CONSTRAINT `idMascota` FOREIGN KEY (`idMascota`) REFERENCES `mascota` (`idMascota`),
  CONSTRAINT `idVacuna` FOREIGN KEY (`idVacuna`) REFERENCES `vacuna` (`idVacuna`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `expediente` VALUES (1,5,9,1,"mareo"),
(2,23,9,1,"\t Herida en pata \t"),
(3,31,7,1,"\tProblemas digestivos \t"),
(4,17,4,1,"\tControl de peso \t"),
(5,54,14,1,"\tVacunación y chequeo\t"),
(6,1,12,1,"\tTos persistente \t"),
(7,42,1,1,"\tCorte en oreja\t"),
(8,9,15,1,"\tArtritis\t"),
(9,16,8,1,"\tOtitis \t"),
(10,36,11,1,"\tVacunación y desparasitación\t"),
(11,2,3,1,"\tProblemas digestivos\t"),
(12,29,7,1,"\t Control de peso  \t"),
(13,56,6,1,"\tHerida en pata \t"),
(14,35,2,1,"\tGripe felina\t"),
(15,49,14,1,"\t Problemas dentales\t"),
(16,14,15,1,"\t Vacunación y chequeo\t"),
(17,25,9,1,"\tCorte en pata \t"),
(18,7,7,1,"\t Artritis  \t"),
(19,47,4,1,"\t Otitis   \t"),
(20,30,14,1,"\t Vacunación y desparasitación \t"),
(21,5,6,1,"\tHerida en cola \t"),
(22,38,1,1,"\tProblemas digestivos  \t"),
(23,22,15,1,"\tControl de peso  \t"),
(24,60,8,1,"\t Vacunación y chequeo\t"),
(25,8,11,1,"\tCorte en oreja \t"),
(26,51,3,1,"\t Artritis  \t"),
(27,21,7,1,"\tTos persistente\t"),
(28,44,6,1,"\tGripe canina  \t"),
(29,3,2,1,"\tProblemas digestivos \t"),
(30,46,14,1,"\tHerida en pata\t"),
(31,20,15,1,"\t Problemas dentales\t"),
(32,10,9,1,"\tVacunación y chequeo\t"),
(33,11,7,1,"\tCorte en pata \t"),
(34,18,4,1,"\t Artritis  \t"),
(35,34,9,1,"\tTos persistente \t"),
(36,59,12,1,"\tGripe canina \t"),
(37,33,1,1,"\tHerida en cola \t"),
(38,52,15,1,"\tProblemas digestivos \t"),
(39,28,8,1,"\t Control de peso \t"),
(40,26,2,1,"\tVacunación y desparasitación\t"),
(41,50,3,1,"\tHerida en pata \t"),
(42,15,7,1,"\tProblemas dentales  \t"),
(43,19,6,1,"\tVacunación y chequeo\t"),
(44,12,2,1,"\t Corte en oreja \t"),
(45,58,14,1,"\t Artritis \t"),
(46,40,15,1,"\tHerida en pata\t"),
(47,13,9,1,"\tGripe felina \t"),
(48,4,7,1,"\tProblemas digestivos \t"),
(49,6,4,1,"\tControl de peso\t"),
(50,43,11,1,"\t Vacunación y desparasitación\t"),
(51,32,12,1,"\t Herida en cola\t"),
(52,27,1,1,"\t Problemas dentales\t"),
(53,39,15,1,"\tVacunación y chequeo \t"),
(54,24,8,1,"\tCorte en pata \t"),
(55,53,11,1,"\tArtritis  \t"),
(56,45,3,1,"\t Tos persistente \t"),
(57,57,7,1,"\tGripe canina \t"),
(58,37,6,1,"\tControl de peso\t"),
(59,41,2,1,"\tHerida en pata \t"),
(60,16,13,1,"\t Problemas digestivos \t"),
(61,12,5,1,"Uno");


DROP TABLE IF EXISTS `factura`;

CREATE TABLE `factura` (
  `idFactura` int NOT NULL AUTO_INCREMENT,
  `pago` float DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `idTipoDePago` int NOT NULL,
  `idReceta` int NOT NULL,
  `idCliente` int NOT NULL,
  `estatus` tinyint(1) DEFAULT NULL,
  `idConcepto` int NOT NULL,
  PRIMARY KEY (`idFactura`),
  KEY `fk_Factura_TipoDePago1_idx` (`idTipoDePago`),
  KEY `fk_Factura_Receta1_idx` (`idReceta`),
  KEY `fk_Factura_Cliente1_idx` (`idCliente`),
  KEY `fk_Factura_Concepto1_idx` (`idConcepto`),
  CONSTRAINT `fk_Factura_Cliente1` FOREIGN KEY (`idCliente`) REFERENCES `cliente` (`idCliente`),
  CONSTRAINT `fk_Factura_Concepto1` FOREIGN KEY (`idConcepto`) REFERENCES `concepto` (`idConcepto`),
  CONSTRAINT `fk_Factura_Receta1` FOREIGN KEY (`idReceta`) REFERENCES `receta` (`idReceta`),
  CONSTRAINT `fk_Factura_TipoDePago1` FOREIGN KEY (`idTipoDePago`) REFERENCES `tipodepago` (`idTipoDePago`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `factura` VALUES (1,500,"2023-08-10",8,42,16,1,15),
(2,350,"2023-08-11",1,3,1,1,1),
(3,800,"2023-08-12",5,25,3,1,3),
(4,600,"2023-08-13",7,16,9,1,14),
(5,450,"2023-08-14",3,12,46,1,12),
(6,550,"2023-08-15",7,35,13,1,9),
(7,420,"2023-08-16",6,48,18,1,4),
(8,700,"2023-08-17",1,26,22,1,6),
(9,900,"2023-08-18",4,16,1,1,7),
(10,300,"2023-08-19",6,18,3,1,6),
(11,450,"2023-08-20",8,20,7,1,9),
(12,600,"2023-08-21",1,9,6,1,3),
(13,550,"2023-08-22",5,5,5,1,2),
(14,750,"2023-08-23",5,28,4,1,7),
(15,400,"2023-08-24",7,29,23,1,1),
(16,500,"2023-08-25",7,37,18,1,8),
(17,320,"2023-08-26",6,42,23,1,12),
(18,680,"2023-08-27",2,17,28,1,14),
(19,520,"2023-08-28",4,42,29,1,5),
(20,380,"2023-08-29",6,60,58,1,15),
(21,480,"2023-08-30",8,25,60,1,1),
(22,550,"2023-08-31",3,16,45,1,3),
(23,720,"2023-09-01",5,12,12,1,9),
(24,900,"2023-09-02",4,35,16,1,9),
(25,420,"2023-09-03",3,48,60,1,7),
(26,520,"2023-09-04",4,16,3,1,7),
(27,360,"2023-09-05",6,19,9,1,15),
(28,640,"2023-09-06",1,18,46,1,1),
(29,470,"2023-09-07",4,20,13,1,3),
(30,300,"2023-09-08",8,23,18,1,14),
(31,420,"2023-09-09",8,5,22,1,12),
(32,550,"2023-09-10",1,28,1,1,9),
(33,780,"2023-09-11",6,8,3,1,4),
(34,910,"2023-09-12",8,37,54,1,3),
(35,430,"2023-09-13",3,42,6,1,12),
(36,520,"2023-09-14",7,6,5,1,6),
(37,390,"2023-09-15",6,42,51,1,9),
(38,660,"2023-09-16",7,3,12,1,7),
(39,480,"2023-09-17",4,5,18,1,2),
(40,350,"2023-09-18",6,16,23,1,6),
(41,470,"2023-09-19",8,12,36,1,1),
(42,600,"2023-09-20",1,35,29,1,8),
(43,540,"2023-09-21",5,41,58,1,12),
(44,720,"2023-09-22",4,26,9,1,14),
(45,390,"2023-09-23",3,32,6,1,4),
(46,490,"2023-09-24",2,18,12,1,12),
(47,350,"2023-09-25",3,20,7,1,1),
(48,690,"2023-09-26",1,9,6,1,3),
(49,560,"2023-09-27",4,8,5,1,2),
(50,340,"2023-09-28",7,28,4,1,9),
(51,460,"2023-09-29",8,2,18,1,8),
(52,580,"2023-09-30",1,37,23,1,7),
(53,600,"2023-10-01",5,1,23,1,6),
(54,760,"2023-10-02",2,17,3,1,9),
(55,410,"2023-10-03",3,5,29,1,1),
(56,500,"2023-10-04",7,33,53,1,3),
(57,370,"2023-10-05",5,44,23,1,2),
(58,730,"2023-10-06",1,37,2,1,9),
(59,540,"2023-10-07",7,31,12,1,8),
(60,320,"2023-10-08",2,17,7,1,7);


DROP TABLE IF EXISTS `mascota`;

CREATE TABLE `mascota` (
  `idMascota` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `Peso` float DEFAULT NULL,
  `sexo` varchar(2) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `idRaza` int NOT NULL,
  `estatus` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idMascota`),
  KEY `fk_Mascota_Raza1_idx` (`idRaza`),
  CONSTRAINT `fk_Mascota_Raza1` FOREIGN KEY (`idRaza`) REFERENCES `raza` (`idRaza`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `mascota` VALUES (1,"\tFifo\t",5,"\tM",1,1),
(2,"\tMax \t","10.5","\tM",1,1),
(3,"\t Bugs \t","7.2","\tH",2,1),
(4,"\t Rocky\t","1.8","\tM",3,1),
(5,"\tDaisy\t",12,"\tH",1,1),
(6,"\t Coco \t","8.5","\tM",4,1),
(7,"\t Lucy \t","4.3","\tH",5,1),
(8,"\tCharlie\t","9.7","\tM",8,1),
(9,"\tBella \t","11.2","\tH",10,1),
(10,"\tBailey\t","6.1","\tM",6,1),
(11,"\tSadie\t","14.3","\tH",5,1),
(12,"\tMilo \t","8.9","\tM",1,1),
(13,"\tToby \t","2.5","\tH",2,1),
(14,"\tRuby \t","7.8","\tH",5,1),
(15,"\tLoki      \t",9,"\tH",2,1),
(16,"\tZoe       \t","5.2","\tH",9,1),
(17,"\tLeo       \t","11.5","\tM",7,1),
(18,"\tRoxy      \t",7,"\tM",6,1),
(19,"\tChico     \t","4.7","\tM",8,1),
(20,"\tMia       \t","10.8","\tH",2,1),
(21,"\tCody      \t","3.4","\tH",7,1),
(22,"\tLily      \t","9.2","\tH",10,1),
(23,"\tJack      \t","12.6","\tM",2,1),
(24,"\tSophie    \t","6.8","\tH",9,1),
(25,"\tOscar     \t","2.9","\tM",8,1),
(26,"\tMolly     \t","8.1","\tH",1,1),
(27,"\tBear      \t","11.9","\tM",2,1),
(28,"\tMaggie    \t","4.4","\tH",1,1),
(29,"\tMax       \t","9.6","\tM",2,1),
(30,"\tLucy      \t","7.3","\tH",2,1),
(31,"\tBuddy     \t","3.1","\tM",2,1),
(32,"\tBailey    \t","10.7","\tM",1,1),
(33,"\tRocky     \t","5.9","\tM",1,1),
(34,"\tZoe       \t","1.2","\tH",2,1),
(35,"\tChloe     \t","12.4","\tH",1,1),
(36,"\tLuna      \t","7.6","\tH",2,1),
(37,"\tDuke      \t","4.8","\tM",1,1),
(38,"\tCoco      \t","9.3","\tM",1,1),
(39,"\tLola      \t",11,"\tH",1,1),
(40,"\tCharlie   \t","6.5","\tM",1,1),
(41,"\tBentley   \t","2.7","\tH",1,1),
(42,"\tSasha     \t","8.4","\tH",1,1),
(43,"\tSophie    \t","3.5","\tH",2,1),
(44,"\tTeddy     \t","10.1","\tM",1,1),
(45,"\tMilo      \t","6.7","\tM",2,1),
(46,"\tPenny     \t",4,"\tH",2,1),
(47,"\tLeo       \t","12.3","\tM",2,1),
(48,"\tLily      \t","8.2","\tH",1,1),
(49,"\tCooper    \t","5.6","\tM",2,1),
(50,"\tLola      \t",10,"\tH",2,1),
(51,"\tRiley     \t","7.1","\tM",10,1),
(52,"\tMia       \t","3.3","\tH",2,1),
(53,"\tHarley    \t","11.7","\tM",1,1),
(54,"\tRuby      \t","6.4","\tH",2,1),
(55,"\tMaddie    \t","1.5","\tH",1,1),
(56,"\tDaisy     \t","9.8","\tH",2,1),
(57,"\tBailey    \t","4.5","\tH",2,1),
(58,"\tBear      \t","7.9","\tM",1,1),
(59,"\tLuna      \t","12.1","\tH",1,1),
(60,"\tJosso\t","6.6","\tM",2,1);


DROP TABLE IF EXISTS `medicamento`;

CREATE TABLE `medicamento` (
  `idMedicamento` int NOT NULL AUTO_INCREMENT,
  `medicamento` varchar(60) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idMedicamento`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `medicamento` VALUES (1,"\tParacetamol\t"),
(2,"\tIbuprofeno              \t"),
(3,"\t Enrofloxacino\t"),
(4,"\tMetronidazol\t"),
(5,"\tAmoxicilina \t"),
(6,"\tFenbendazol\t"),
(7,"\tCefalexina \t"),
(8,"\t Diazepam\t"),
(9,"\tPrednisona\t"),
(10,"\tRanitidina\t"),
(11,"\tIvermectina\t"),
(12,"\tTramadol \t"),
(13,"\tCiprofloxacino\t"),
(14,"\tFenobarbital \t"),
(15,"\tFipronil\t");


DROP TABLE IF EXISTS `pais`;

CREATE TABLE `pais` (
  `idPais` int NOT NULL AUTO_INCREMENT,
  `pais` varchar(10) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idPais`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `pais` VALUES (1,"\tMexico\t");


DROP TABLE IF EXISTS `raza`;

CREATE TABLE `raza` (
  `idRaza` int NOT NULL AUTO_INCREMENT,
  `tipo` varchar(45) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idRaza`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `raza` VALUES (1,"\tPerro\t"),
(2,"\tGato\t"),
(3,"\tConejo\t"),
(4,"\tLoro\t"),
(5,"\tHamster\t"),
(6,"\tTortuga\t"),
(7,"\tCerdo\t"),
(8,"\tPato\t"),
(9,"\tCabra\t"),
(10,"\tSerpiente ");


DROP TABLE IF EXISTS `receta`;

CREATE TABLE `receta` (
  `idReceta` int NOT NULL AUTO_INCREMENT,
  `padecimiento` varchar(60) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`idReceta`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `receta` VALUES (1,"\tGripe canina \t","2023-08-10"),
(2,"\tDermatitis felina \t","2023-08-11"),
(3,"\tOtitis en perros  \t","2023-08-12"),
(4,"\tGastritis en gatos\t","2023-08-13"),
(5,"\tConjuntivitis canina\t","2023-08-14"),
(6,"\tDiarrea felina \t","2023-08-15"),
(7,"\tInsuf. renal en perros\t","2023-08-16"),
(8,"\t Herida en gatos \t","2023-08-17"),
(9,"\tArtritis canina \t","2023-08-18"),
(10,"\tParásitos en felinos\t","2023-08-19"),
(11,"\tObesidad en perros \t","2023-08-20"),
(12,"\tUrolitiasis en gatos\t","2023-08-21"),
(13,"\tAlergia canina \t","2023-08-22"),
(14,"\tGingivitis felina\t","2023-08-23"),
(15,"\tEpilepsia en perros\t","2023-08-24"),
(16,"\tDiabetes en gatos\t","2023-08-25"),
(17,"\tInfección urinaria canina\t","2023-08-26"),
(18,"\tTrastorno digestivo en felinos\t","2023-08-27"),
(19,"\tEnfermedad cardíaca en perros\t","2023-08-28"),
(20,"\t Ojos rojos en gatos \t","2023-08-29"),
(21,"\tProblema dental en caninos\t","2023-08-30"),
(22,"\tAsma felina \t","2023-08-31"),
(23,"\tAnemia en perros \t","2023-09-01"),
(24,"\tProblema renal en gatos\t","2023-09-02"),
(25,"\tParvovirus canino \t","2023-09-03"),
(26,"\tVómitos en felinos \t","2023-09-04"),
(27,"\tAlergia alimentaria en perros\t","2023-09-05"),
(28,"\tSarna en gatos\t","2023-09-06"),
(29,"\tDeshidratación canina\t","2023-09-07"),
(30,"\tInfección en oídos de felinos\t","2023-09-08"),
(31,"\tConvulsiones en perros\t","2023-09-09"),
(32,"\tProblema respiratorio en gatos\t","2023-09-10"),
(33,"\tObstrucción urinaria canina\t","2023-09-11"),
(34,"\t Diarrea aguda en felinos\t","2023-09-12"),
(35,"\tEnfermedad del hígado en perros\t","2023-09-13"),
(36,"\t Problema de piel en gatos\t","2023-09-14"),
(37,"\t Fractura en caninos\t","2023-09-15"),
(38,"\tEnfermedad del tracto urinario felino\t","2023-09-16"),
(39,"\tProblema digestivo en perros\t","2023-09-17"),
(40,"\tLesión en gatos \t","2023-09-18"),
(41,"\tProblema hormonal en caninos\t","2023-09-19"),
(42,"\tInfección respiratoria en felinos\t","2023-09-20"),
(43,"\tPancreatitis en perros\t","2023-09-21"),
(44,"\tHipertiroidismo en gatos\t","2023-09-22"),
(45,"\tParásitos intestinales caninos\t","2023-09-23"),
(46,"\tCistitis en felinos\t","2023-09-24"),
(47,"\tDermatitis alérgica en perros\t","2023-09-25"),
(48,"\tEnfermedad viral en gatos\t","2023-09-26"),
(49,"\tProblema gastrointestinal en caninos\t","2023-09-27"),
(50,"\tProblema ocular en felinos\t","2023-09-28"),
(51,"\tInsuf. cardiaca en perros \t","2023-09-29"),
(52,"\t Infección de oídos en gatos\t","2023-09-30"),
(53,"\tHipotiroidismo canino\t","2023-10-01"),
(54,"\tSíndrome urinario felino\t","2023-10-02"),
(55,"\tAlergia cutánea en perros\t","2023-10-03"),
(56,"\tProblema dental en gatos\t","2023-10-04"),
(57,"\tEnfermedad renal en caninos\t","2023-10-05"),
(58,"\tVómitos crónicos en felinos\t","2023-10-06"),
(59,"\tDiabetes mellitus en perro\t","2023-10-07"),
(60,"\tEnfermedad del hígado en gatos\t","2023-10-08");


DROP TABLE IF EXISTS `recetamedica`;

CREATE TABLE `recetamedica` (
  `idRecetaMedica` int NOT NULL AUTO_INCREMENT,
  `idReceta` int DEFAULT NULL,
  `idMedicamento` int DEFAULT NULL,
  `estatus` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idRecetaMedica`),
  KEY `idReceta_idx` (`idReceta`),
  KEY `idMedicamento_idx` (`idMedicamento`),
  CONSTRAINT `idMedicamento` FOREIGN KEY (`idMedicamento`) REFERENCES `medicamento` (`idMedicamento`),
  CONSTRAINT `idReceta` FOREIGN KEY (`idReceta`) REFERENCES `receta` (`idReceta`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `recetamedica` VALUES (1,2,1,1),
(2,16,10,1),
(3,13,3,1),
(4,6,4,1),
(5,3,5,1),
(6,45,6,1),
(7,4,7,1),
(8,5,8,1),
(9,23,9,1),
(10,7,10,1),
(11,8,11,1),
(12,9,12,1),
(13,10,7,1),
(14,11,9,1),
(15,12,15,1);


DROP TABLE IF EXISTS `relacionmascota`;

CREATE TABLE `relacionmascota` (
  `idrelacionMascota` int NOT NULL AUTO_INCREMENT,
  `idCliente` int DEFAULT NULL,
  `idMascota` int NOT NULL,
  PRIMARY KEY (`idrelacionMascota`),
  KEY `idCLiente_idx` (`idCliente`),
  KEY `fk_relacionMascota_Mascota1_idx` (`idMascota`),
  CONSTRAINT `fk_relacionMascota_Mascota1` FOREIGN KEY (`idMascota`) REFERENCES `mascota` (`idMascota`),
  CONSTRAINT `idCLiente` FOREIGN KEY (`idCliente`) REFERENCES `cliente` (`idCliente`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `relacionmascota` VALUES (1,12,23),
(2,1,2),
(3,2,12),
(4,36,4),
(5,2,5),
(6,2,6),
(7,25,9),
(8,3,8),
(9,4,9),
(10,5,10),
(11,11,11),
(12,5,45),
(13,13,13),
(14,1,8),
(15,15,15),
(16,2,4),
(17,17,9),
(18,3,2),
(19,19,19),
(20,20,17),
(21,21,21),
(22,3,22),
(23,8,23),
(24,9,60),
(25,36,54),
(26,3,26),
(27,27,27),
(28,28,28),
(29,26,29),
(30,30,30),
(31,31,16),
(32,32,21),
(33,52,4),
(34,34,34),
(35,35,35),
(36,36,9),
(37,38,7),
(38,23,38),
(39,39,39),
(40,11,40),
(41,5,32),
(42,13,52),
(43,1,34),
(44,15,6),
(45,2,36),
(46,17,9),
(47,3,47),
(48,19,48),
(49,20,12),
(50,21,50),
(51,3,51),
(52,8,19),
(53,9,20),
(54,36,21),
(55,3,3),
(56,27,8),
(57,28,9),
(58,26,36),
(59,30,3),
(60,31,60);


DROP TABLE IF EXISTS `tipodepago`;

CREATE TABLE `tipodepago` (
  `idTipoDePago` int NOT NULL,
  `descripcion` varchar(500) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idTipoDePago`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tipodepago` VALUES (1,"\t Efectivo \t"),
(2,"\tTarjeta de crédito\t"),
(3,"\t Tarjeta de débito \t"),
(4,"\tTransferencia bancaria\t"),
(5,"\t Cheque \t"),
(6,"\tPago en línea \t"),
(7,"\tVale o cupón\t"),
(8,"\tFinanciamiento \t");


DROP TABLE IF EXISTS `vacuna`;

CREATE TABLE `vacuna` (
  `idVacuna` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idVacuna`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `vacuna` VALUES (1,"\tRabia           \t"),
(2,"\tParvovirus      \t"),
(3,"\tMoquillo        \t"),
(4,"\tLeptospirosis   \t"),
(5,"\tBordetella      \t"),
(6,"\tCoronavirus     \t"),
(7,"\tInfluenza       \t"),
(8,"\tHepatitis       \t"),
(9,"\tLyme            \t"),
(10,"\tLeucemia        \t"),
(11,"\tCalicivirus     \t"),
(12,"\tRinotraqueitis  \t"),
(13,"\tPanleucopenia   \t"),
(14,"\tClamidia        \t"),
(15,"\tToxoplasmosis   \t");


DROP TABLE IF EXISTS `veterinario`;

CREATE TABLE `veterinario` (
  `idVeterinario` int NOT NULL AUTO_INCREMENT,
  `cedula` varchar(45) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `nombre` varchar(45) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `apaterno` varchar(45) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `amaterno` varchar(45) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `idConsultorio` int NOT NULL,
  `estatus` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idVeterinario`),
  KEY `fk_Veterinario_Consultorio1_idx` (`idConsultorio`),
  CONSTRAINT `fk_Veterinario_Consultorio1` FOREIGN KEY (`idConsultorio`) REFERENCES `consultorio` (`idConsultorio`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `veterinario` VALUES (1,"\t MV12345\t","\t Ana \t","\tRodríguez  \t","\tGómez      \t",1,1),
(2,"\t MV67890\t","\tCarlos      \t","\tPérez      \t","\tLópez      \t",10,1),
(3,"\tMV54321\t","\tLaura       \t","\tMartínez   \t","\tGarcía     \t",3,1),
(4,"\tMV98765\t","\tEduardo     \t","\tSánchez    \t","\tGonzález   \t",7,1),
(5,"\t MV23456\t","\tMaría       \t","\tLópez      \t","\tRamírez    \t",5,1),
(6,"\tMV78901\t","\tJuan        \t","\tHernández  \t","\tTorres     \t",9,1),
(7,"\tMV34567 \t","\tAndrea      \t","\tDíaz       \t","\tVargas     \t",7,1),
(8,"\tMV89012\t","\tManuel      \t","\tReyes      \t","\tSoto       \t",4,1),
(9,"\tMV45678\t","\tGabriela    \t","\tGarcía     \t","\tFernández \t",9,1),
(10,"\tMV12346\t","\tAlejandro   \t","\tRíos       \t","\tNavarro    \t",3,1);


SET foreign_key_checks = 1;
